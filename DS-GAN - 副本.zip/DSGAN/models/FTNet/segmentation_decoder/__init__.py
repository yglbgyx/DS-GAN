"""Model Zoo"""
# https://github.com/qubvel/segmentation_models.pytorch
from .ftnet import *
