#!/usr/bin/env python

#####################################################################################################################################################################
# FTNet                                                                                                                                                             #
# Copyright 2020 Tufts University.                                                                                                                                  #                                                                                                                #
# Please see LICENSE file for full terms.                                                                                                                           #                                                                                                                                              #                                                                                                                                                 #
#####################################################################################################################################################################

import torch
import torch.nn as nn
import logging
import numpy as np
logger = logging.getLogger('pytorch_lightning')
import torch.nn.functional as F
from models.FTNet.encoder.pidinet import Layer_PDC


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=8):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        # 利用1x1卷积代替全连接
        self.fc1   = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)
        self.relu1 = nn.PReLU()
        self.fc2   = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out)

class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)

class cbam_block(nn.Module):
    def __init__(self, channel, ratio=8, kernel_size=7):
        super(cbam_block, self).__init__()
        self.channelattention = ChannelAttention(channel, ratio=ratio)
        self.spatialattention = SpatialAttention(kernel_size=kernel_size)

    def forward(self, x):
        x = x * self.channelattention(x)
        x = x * self.spatialattention(x)
        return x

def conv3x3(in_planes, out_planes, stride=1, use_bias=True):
    """3x3 convolution with padding"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride, padding=1, bias=use_bias)


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, dilation=1, previous_dilation=1,
                 downsample=None, norm_layer=nn.BatchNorm2d, relu_layer=nn.ReLU, use_bias=True, is_downsample=True):

        super(BasicBlock, self).__init__()
        self.is_downsample = is_downsample
        if is_downsample:
            self.conv1 = nn.Conv2d(inplanes, planes, 3, stride, dilation, dilation, bias=use_bias)
            self.bn1 = norm_layer(planes)
            self.relu = relu_layer()
            self.conv2 = nn.Conv2d(planes, planes, 3, 1, previous_dilation, dilation=previous_dilation, bias=use_bias)
            self.bn2 = norm_layer(planes)
            self.downsample = downsample
            self.stride = stride
        else:
            self.conv3 = nn.Conv2d(inplanes, inplanes, 3, 1, previous_dilation, dilation=previous_dilation, bias=use_bias)
            self.bn3 = norm_layer(inplanes)
            self.relu = relu_layer()
            self.conv4 = nn.Conv2d(inplanes, planes, 3, stride, dilation, dilation, bias=use_bias)
            self.bn4 = norm_layer(planes)
            self.upsample = downsample  # 这里其实应该是 upsample
            self.stride = stride

    def forward(self, x):
        identity = x
        if self.is_downsample:
            out = self.conv1(x)
            out = self.bn1(out)
            out = self.relu(out)

            out = self.conv2(out)
            out = self.bn2(out)

            if self.downsample is not None:
                identity = self.downsample(x)

            out += identity
            out = self.relu(out)
            return out
        else:
            out = self.conv3(x)
            out = self.bn3(out)
            out = self.relu(out)

            out = self.conv4(out)
            out = self.bn4(out)

            if self.upsample is not None:
                identity = self.upsample(x)

            out += identity
            out = self.relu(out)
            return out

class PDCS_Block(nn.Module):
    def __init__(self, inplanes, planes):
        super(PDCS_Block, self).__init__()
        self.relu1 = nn.ReLU()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, padding=0)
        self.block = Layer_PDC(planes, planes)

    def forward(self, x):
        x = self.relu1(x)
        x = self.conv1(x)
        x = self.block(x)
        return x


class Bottleneck(nn.Module):
    def __init__(self, inplanes, planes, stride=1, downsample=None, groups=1,
                 base_width=64, dilation=1, norm_layer=None, relu_layer=nn.ReLU, use_bias=True, **kwargs):
        super(Bottleneck, self).__init__()

        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, stride=1, padding=0, groups=1, bias=use_bias)
        self.bn1 = norm_layer(planes)
        self.conv2 = nn.Conv2d(planes, planes, 3, stride, dilation, dilation, groups, bias=use_bias)
        self.bn2 = norm_layer(planes)
        self.conv3 = nn.Conv2d(planes, inplanes, kernel_size=1, stride=1, padding=0, groups=1, bias=use_bias)
        self.bn3 = norm_layer(inplanes)
        self.relu = relu_layer()

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        out += identity
        out = self.relu(out)

        return out

class FTUpSample(nn.Module):
    def __init__(self, input, output, stride=1, norm_layer=nn.BatchNorm2d, relu_layer=nn.ReLU, use_bias=True):
        super(FTUpSample, self).__init__()
        self.mult = int(input/output)
        if self.mult == 1:
            self.mult = 2
        self.conv3x3 = nn.Sequential(nn.ReflectionPad2d(1),
                                     nn.Conv2d(input, output, kernel_size=3, stride=1, padding=0, bias=use_bias),
                                     norm_layer(output),
                                     relu_layer())
        # self.convtrans3x3 = nn.Sequential(nn.ConvTranspose2d(input, output, kernel_size=3, stride=2, padding=1, output_padding=1),
        #                                   norm_layer(output),
        #                                   relu_layer())
    def forward(self, x):
        h = x.shape[-2]*self.mult
        w = x.shape[-1]*self.mult
        out = F.interpolate(x, size=(h, w), mode='bilinear', align_corners=True)
        out = self.conv3x3(out)

        # out = self.convtrans3x3(x)

        return out

class FTUpSample1(nn.Module):
    def __init__(self, input, output, stride=1, norm_layer=nn.BatchNorm2d, relu_layer=nn.ReLU, use_bias=True):
        super(FTUpSample1, self).__init__()
        self.mult = int(input/output)
        if self.mult == 1:
            self.mult = 2
        # self.conv3x3 = nn.Sequential(nn.ReflectionPad2d(1),
        #                              nn.Conv2d(input, output, kernel_size=3, stride=1, padding=0, bias=use_bias),
        #                              norm_layer(output),
        #                              relu_layer())
        # self.convtrans3x3 = nn.Sequential(nn.ConvTranspose2d(input, output, kernel_size=3, stride=2, padding=1, output_padding=1),
        #                                   norm_layer(output),
        #                                   relu_layer())
    def forward(self, x):
        h = x.shape[-2]*self.mult
        w = x.shape[-1]*self.mult
        out = F.interpolate(x, size=(h, w), mode='bilinear', align_corners=True)
        # out = self.conv3x3(out)

        # out = self.convtrans3x3(x)

        return out


class FeatureTransverseDecoder(nn.Module):
    def __init__(self, num_branches, blocks, num_blocks, num_inchannels, num_channels, dilation, edge_extract=None,
                 norm_layer=nn.BatchNorm2d, relu_layer=nn.ReLU, use_bias=True):
        super(FeatureTransverseDecoder, self).__init__()
        self._check_branches(num_branches,
                             blocks,
                             num_blocks,
                             num_inchannels,
                             num_channels,
                             dilation)

        self.num_inchannels = num_inchannels.copy()
        self.num_branches = num_branches
        self.dilation = dilation
        self.edge_extract = edge_extract

        edge_list = []
        for i in edge_extract:
            edge_list.append(nn.Sequential(nn.Conv2d(in_channels=self.num_inchannels[i],
                                                     out_channels=1,
                                                     kernel_size=3,
                                                     stride=1,
                                                     padding=3 // 2,
                                                     bias=use_bias),
                                           norm_layer(1),
                                           relu_layer())
                             )

        self.edges = nn.ModuleList(edge_list)

        self.final_edge = nn.Sequential(nn.Conv2d(in_channels=len(edge_extract),
                                                  out_channels=1,
                                                  kernel_size=3,
                                                  stride=1,
                                                  padding=3 // 2,
                                                  bias=True))

        self.branches = self._make_branches(num_inchannels, num_branches, blocks, num_blocks, num_channels, norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)

        # Layer3_Down_C_2048_1024 = nn.Sequential(nn.Conv2d(num_inchannels[3], int(num_inchannels[3]/2), kernel_size=1, stride=1, bias=use_bias), norm_layer(int(num_inchannels[3]/2)))
        # self.Layer3_Down1_2048_1024 = BasicBlock(inplanes=num_inchannels[3],planes=int(num_inchannels[3]/2),downsample=Layer3_Down_C_2048_1024,norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # Layer3_Down_C_1024_512 = nn.Sequential(nn.Conv2d(int(num_inchannels[3]/2), int(num_inchannels[3]/4), kernel_size=1, stride=1, bias=use_bias), norm_layer(int(num_inchannels[3]/4)))
        # self.Layer3_Down1_1024_512 = BasicBlock(inplanes=int(num_inchannels[3]/2),planes=int(num_inchannels[3]/4),downsample=Layer3_Down_C_1024_512,norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # Layer3_Down_C_512_256 = nn.Sequential(nn.Conv2d(int(num_inchannels[3]/4), int(num_inchannels[3]/8), kernel_size=1, stride=1, bias=use_bias), norm_layer(int(num_inchannels[3]/8)))
        # self.Layer3_Down1_512_256 = BasicBlock(inplanes=int(num_inchannels[3]/4),planes=int(num_inchannels[3]/8),downsample=Layer3_Down_C_512_256,norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # Layer3_Down_C_256_128 = nn.Sequential(nn.Conv2d(int(num_inchannels[3]/8), int(num_inchannels[3]/16), kernel_size=1, stride=1, bias=use_bias), norm_layer(int(num_inchannels[3]/16)))
        # self.Layer3_Down1_256_128 = BasicBlock(inplanes=int(num_inchannels[3]/8),planes=int(num_inchannels[3]/16),downsample=Layer3_Down_C_256_128,norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        #
        # self.Layer2_Up_2048_1024 = FTUpSample(input=num_inchannels[2]*2, output=num_inchannels[2], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # Layer2_Down_C_1024_512 = nn.Sequential(nn.Conv2d(num_inchannels[2], int(num_inchannels[2]/2), kernel_size=1, stride=1, bias=use_bias), norm_layer(int(num_inchannels[2]/2)))
        # self.Layer2_Down1_1024_512 = BasicBlock(inplanes=num_inchannels[2],planes=int(num_inchannels[2]/2),downsample=Layer2_Down_C_1024_512,norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # self.Layer2_Up_1024_512 = FTUpSample(input=num_inchannels[2], output=int(num_inchannels[2]/2), norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # Layer2_Down_C_512_256 = nn.Sequential(nn.Conv2d(int(num_inchannels[2]/2), int(num_inchannels[2]/4), kernel_size=1, stride=1, bias=use_bias), norm_layer(int(num_inchannels[2]/4)))
        # self.Layer2_Down1_512_256 = BasicBlock(inplanes=int(num_inchannels[2]/2),planes=int(num_inchannels[2]/4),downsample=Layer2_Down_C_512_256,norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # self.Layer2_Up_512_256 = FTUpSample(input=int(num_inchannels[2]/2), output=int(num_inchannels[2]/4), norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # Layer2_Down_C_256_128 = nn.Sequential(nn.Conv2d(int(num_inchannels[2]/4), int(num_inchannels[2]/8), kernel_size=1, stride=1, bias=use_bias), norm_layer(int(num_inchannels[2]/8)))
        # self.Layer2_Down1_256_128 = BasicBlock(inplanes=int(num_inchannels[2]/4),planes=int(num_inchannels[2]/8),downsample=Layer2_Down_C_256_128,norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # self.Layer2_Up_256_128 = FTUpSample(input=int(num_inchannels[2]/4), output=int(num_inchannels[2]/8), norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.Layer2_Fusion1_Out = BasicBlock(inplanes=num_channels[2], planes=num_channels[2], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        #
        # self.Layer1_Up_1024_512 = FTUpSample(input=num_inchannels[1]*2, output=num_inchannels[1], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # Layer1_Down_C_512_256 = nn.Sequential(nn.Conv2d(num_inchannels[1], int(num_inchannels[1]/2), kernel_size=1, stride=1, bias=use_bias), norm_layer(int(num_inchannels[1]/2)))
        # self.Layer1_Down1_512_256 = BasicBlock(inplanes=num_inchannels[1],planes=int(num_inchannels[1]/2),downsample=Layer1_Down_C_512_256,norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # self.Layer1_Up_512_256 = FTUpSample(input=num_inchannels[1], output=int(num_inchannels[1]/2), norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # Layer1_Down_C_256_128 = nn.Sequential(nn.Conv2d(int(num_inchannels[1]/2), int(num_inchannels[1]/4), kernel_size=1, stride=1, bias=use_bias), norm_layer(int(num_inchannels[1]/4)))
        # self.Layer1_Down1_256_128 = BasicBlock(inplanes=int(num_inchannels[1]/2),planes=int(num_inchannels[1]/4),downsample=Layer1_Down_C_256_128,norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # self.Layer1_Up_256_128 = FTUpSample(input=int(num_inchannels[1]/2), output=int(num_inchannels[1]/4), norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.Layer1_Fusion1_Out = BasicBlock(inplanes=num_channels[1], planes=num_channels[1], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        #
        # self.Layer0_Up_512_256 = FTUpSample(input=num_inchannels[0]*2, output=num_inchannels[0], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # Layer0_Down_C_256_128 = nn.Sequential(nn.Conv2d(num_inchannels[0], int(num_inchannels[0]/2), kernel_size=1, stride=1, bias=use_bias), norm_layer(int(num_inchannels[0]/2)))
        # self.Layer1_Down0_256_128 = BasicBlock(inplanes=num_inchannels[0],planes=int(num_inchannels[0]/2),downsample=Layer0_Down_C_256_128,norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # self.Layer0_Up_256_128 = FTUpSample(input=num_inchannels[0], output=int(num_inchannels[0]/2), norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.Layer0_Fusion1_Out = BasicBlock(inplanes=num_channels[0], planes=num_channels[0], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)

        self.Layer3_Down1_Att = cbam_block(num_channels[3])
        # self.Layer3_Down1_Out = PDCS_Block(inplanes=num_inchannels[3], planes=num_channels[3])
        # self.Layer3_Fusion1_Out = PDCS_Block(inplanes=num_channels[3], planes=num_channels[3])
        # self.Layer3_Fusion2_Out = PDCS_Block(inplanes=num_channels[3], planes=num_channels[3])
        # self.Layer3_Down2_Out = nn.Sequential(nn.Conv2d(num_channels[3], num_channels[3], kernel_size=3, stride=2, padding=1, bias=use_bias), norm_layer(num_channels[3]), relu_layer())
        # self.Layer3_Fusion3_Out = BasicBlock(inplanes=num_channels[3],planes=num_channels[3],norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # self.Layer3_Fusion4_Out = BasicBlock(inplanes=num_channels[3], planes=num_channels[3], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)


        Layer2_Down_C = nn.Sequential(nn.Conv2d(num_inchannels[2], num_channels[2], kernel_size=1, stride=1, bias=use_bias), norm_layer(num_channels[2]))
        self.Layer2_Up_HW = FTUpSample(input=num_channels[2], output=num_channels[2], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        self.Layer2_Up_Out = BasicBlock(inplanes=num_channels[2],planes=num_channels[2],norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=False)
        self.Layer2_Down1_Out = BasicBlock(inplanes=num_inchannels[2],planes=num_channels[2],downsample=Layer2_Down_C,norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        self.Layer2_Down1_Att  = cbam_block(num_channels[2])
        self.Layer2_Fusion1_Out = BasicBlock(inplanes=num_channels[2],planes=num_channels[2],norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        self.Layer2_Fusion2_Out = BasicBlock(inplanes=num_channels[2], planes=num_channels[2], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # self.Layer2_Down2_Out = nn.Sequential(nn.Conv2d(num_channels[2], num_channels[2], kernel_size=3, stride=2, padding=1, bias=use_bias), norm_layer(num_channels[2]), relu_layer())
        # self.Layer2_Fusion3_Out = BasicBlock(inplanes=num_channels[2],planes=num_channels[2],norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # self.Layer2_Fusion4_Out = BasicBlock(inplanes=num_channels[2], planes=num_channels[2], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # self.Layer2_Up_HW = FTUpSample1(input=num_channels[2], output=num_channels[2], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.Layer2_Up_Out = PDCS_Block(inplanes=num_channels[2], planes=num_channels[2])
        # self.Layer2_Down1_Out = PDCS_Block(inplanes=num_inchannels[2], planes=num_channels[2])
        # self.Layer2_Fusion1_Out = PDCS_Block(inplanes=num_channels[2],planes=num_channels[2])
        # self.Layer2_Fusion2_Out = PDCS_Block(inplanes=num_channels[2], planes=num_channels[2])

        Layer1_Down_C = nn.Sequential(nn.Conv2d(num_inchannels[1], num_channels[1], kernel_size=1, stride=1, bias=use_bias), norm_layer(num_channels[1]))
        self.Layer1_Up_HW = FTUpSample(input=num_channels[1], output=num_channels[1], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        self.Layer1_Up_Out = BasicBlock(inplanes=num_channels[1], planes=num_channels[1], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        self.Layer1_Down1_Out = BasicBlock(inplanes=num_inchannels[1], planes=num_channels[1], downsample=Layer1_Down_C, norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        self.Layer1_Down1_Att = cbam_block(num_channels[1])
        self.Layer1_Fusion1_Out = BasicBlock(inplanes=num_channels[1], planes=num_channels[1], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        self.Layer1_Fusion2_Out = BasicBlock(inplanes=num_channels[1], planes=num_channels[1], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # # self.Layer1_Down2_Out = nn.Sequential(nn.Conv2d(num_channels[1], num_channels[1], kernel_size=3, stride=2, padding=1, bias=use_bias), norm_layer(num_channels[1]), relu_layer())
        # self.Layer1_Fusion3_Out = BasicBlock(inplanes=num_channels[1],planes=num_channels[1],norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # self.Layer1_Fusion4_Out = BasicBlock(inplanes=num_channels[1], planes=num_channels[1], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # self.Layer1_Up_HW = FTUpSample1(input=num_channels[1], output=num_channels[1], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.Layer1_Up_Out = PDCS_Block(inplanes=num_channels[1], planes=num_channels[1])
        # self.Layer1_Down1_Out = PDCS_Block(inplanes=num_inchannels[1], planes=num_channels[1])
        # self.Layer1_Fusion1_Out = PDCS_Block(inplanes=num_channels[1], planes=num_channels[1])
        # self.Layer1_Fusion2_Out = PDCS_Block(inplanes=num_channels[1], planes=num_channels[1])

        Layer0_Down_C = nn.Sequential(nn.Conv2d(num_inchannels[0], num_channels[0], kernel_size=1, stride=1, bias=use_bias), norm_layer(num_channels[0]))
        self.Layer0_Up_HW = FTUpSample(input=num_channels[0], output=num_channels[0], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        self.Layer0_Up_Out = BasicBlock(inplanes=num_channels[0], planes=num_channels[0], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        self.Layer0_Down1_Out = BasicBlock(inplanes=num_inchannels[0], planes=num_channels[0], downsample=Layer0_Down_C, norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        self.Layer0_Down1_Att = cbam_block(num_channels[0])
        self.Layer0_Fusion1_Out = BasicBlock(inplanes=num_channels[0], planes=num_channels[0], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        self.Layer0_Fusion2_Out = BasicBlock(inplanes=num_channels[0], planes=num_channels[0], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=True)
        # self.Layer0_Up_HW = FTUpSample1(input=num_channels[0], output=num_channels[0], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.Layer0_Up_Out = PDCS_Block(inplanes=num_channels[0], planes=num_channels[0])
        # self.Layer0_Down1_Out = PDCS_Block(inplanes=num_inchannels[0], planes=num_channels[0])
        # self.Layer0_Fusion1_Out = PDCS_Block(inplanes=num_channels[0], planes=num_channels[0])
        # self.Layer0_Fusion2_Out = PDCS_Block(inplanes=num_channels[0], planes=num_channels[0])

        self.branches_up = self._make_branches(num_inchannels, num_branches, blocks, num_blocks, num_channels, norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=False)
        self.fuse_layers = self._make_fuse_layers(norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        self.relu = relu_layer()

        self.upsample4_3 = FTUpSample(input=num_inchannels[3], output=num_inchannels[2], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.upsample4_2 = FTUpSample(input=num_inchannels[3], output=num_inchannels[1], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.upsample4_1 = FTUpSample(input=num_inchannels[3], output=num_inchannels[0], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.upsample4 = nn.Sequential(
        #     nn.ConvTranspose2d(num_inchannels[3], num_inchannels[2], kernel_size=3, stride=2, padding=1, output_padding=1),
        #     norm_layer(num_inchannels[2]),
        #     relu_layer())
        self.resblock3 = Bottleneck(num_inchannels[2], int(num_inchannels[2]/2), groups=32, norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        self.upsample3_2 = FTUpSample(input=num_inchannels[2], output=num_inchannels[1], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.upsample3_1 = FTUpSample(input=num_inchannels[2], output=num_inchannels[0], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.upsample3 = nn.Sequential(
        #     nn.ConvTranspose2d(num_inchannels[2], num_inchannels[1], kernel_size=3, stride=2, padding=1, output_padding=1),
        #     norm_layer(num_inchannels[1]),
        #     relu_layer())
        self.resblock2 = Bottleneck(num_inchannels[1], int(num_inchannels[1]/2), groups=32, norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        self.upsample2 = FTUpSample(input=num_inchannels[1], output=num_inchannels[0], norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.upsample2 = nn.Sequential(
        #     nn.ConvTranspose2d(num_inchannels[1], num_inchannels[0], kernel_size=3, stride=2, padding=1, output_padding=1),
        #     norm_layer(num_inchannels[0]),
        #     relu_layer())
        self.resblock1 = Bottleneck(num_inchannels[0], int(num_inchannels[0]/2), groups=32, norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        self.upsample1 = FTUpSample(input=num_inchannels[0], output=int(num_inchannels[0]/2), norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.upsample1 = nn.Sequential(
        #     nn.ConvTranspose2d(num_inchannels[0], int(num_inchannels[0]/2), kernel_size=3, stride=2, padding=1, output_padding=1),
        #     norm_layer(int(num_inchannels[0]/2)),
        #     relu_layer())
        self.upsample0 = FTUpSample(input=int(num_inchannels[0]/2), output=int(num_inchannels[0] / 4), norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias)
        # self.upsample0 = nn.Sequential(
        #     nn.ConvTranspose2d(int(num_inchannels[0]/2), int(num_inchannels[0] / 4), kernel_size=3, stride=2, padding=1, output_padding=1),
        #     norm_layer(int(num_inchannels[0] / 4)),
        #     relu_layer())
        self.upsample = nn.Sequential(
            nn.ReflectionPad2d(3),
            nn.Conv2d(int(num_inchannels[0] / 4), 3, kernel_size=7, padding=0),
            nn.Tanh()
        )

    def _check_branches(self, num_branches, blocks, num_blocks, num_inchannels, num_channels, dilation):
        if num_branches != len(num_blocks):
            error_msg = 'NUM_BRANCHES({}) NOT EQUAL TO NUM_BLOCKS({})'.format(num_branches, len(num_blocks))
            logger.error(error_msg)
            raise ValueError(error_msg)

        if num_branches != len(num_channels):
            error_msg = 'NUM_BRANCHES({})  NOT EQUAL TO NUM_CHANNELS({})'.format(num_branches, len(num_channels))
            logger.error(error_msg)
            raise ValueError(error_msg)

        if num_branches != len(num_inchannels):
            error_msg = 'NUM_BRANCHES({})  NOT EQUAL TO NUM_INCHANNELS({})'.format(num_branches, len(num_inchannels))
            logger.error(error_msg)
            raise ValueError(error_msg)

        if num_branches != len(dilation):
            error_msg = 'NUM_BRANCHES({})  NOT EQUAL TO Dilation({})'.format(num_branches, len(dilation))
            logger.error(error_msg)
            raise ValueError(error_msg)

    def _make_one_branch(self, num_inchannels, branch_index, block, num_blocks, num_channels, stride=1, norm_layer=nn.BatchNorm2d, relu_layer=nn.ReLU, use_bias=True, is_downsample=True):
        if is_downsample:
            downsample = None
            if stride != 1 or self.num_inchannels[branch_index] != num_channels[branch_index] * block.expansion:
                downsample = nn.Sequential(nn.Conv2d(self.num_inchannels[branch_index],
                                                     num_channels[branch_index] * block.expansion,
                                                     kernel_size=1,
                                                     stride=stride,
                                                     bias=use_bias),
                                           norm_layer(num_channels[branch_index] * block.expansion))

            layers = []
            layers.append(block(inplanes=self.num_inchannels[branch_index],
                                planes=num_channels[branch_index],
                                stride=stride,
                                downsample=downsample,
                                dilation=self.dilation[branch_index],
                                previous_dilation=self.dilation[branch_index],
                                norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=is_downsample))

            self.num_inchannels[branch_index] = num_channels[branch_index] * block.expansion
            for i in range(1, num_blocks[branch_index]):
                layers.append(block(inplanes=self.num_inchannels[branch_index],
                                    planes=num_channels[branch_index],
                                    dilation=self.dilation[branch_index],
                                    previous_dilation=self.dilation[branch_index],
                                    norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=is_downsample))

            return nn.Sequential(*layers)
        else:
            upsample = None
            if stride != 1 or num_inchannels[branch_index] != num_channels[branch_index] * block.expansion:
                upsample = nn.Sequential(nn.Conv2d(num_channels[branch_index] * block.expansion,
                                                   num_inchannels[branch_index],
                                                   kernel_size=1,
                                                   stride=stride,
                                                   bias=use_bias),
                                           norm_layer(num_inchannels[branch_index]))

            layers = []
            for i in range(1, num_blocks[branch_index]):
                layers.append(block(inplanes=num_channels[branch_index],
                                    planes=num_channels[branch_index],
                                    dilation=self.dilation[branch_index],
                                    previous_dilation=self.dilation[branch_index],
                                    norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=is_downsample))


            layers.append(block(inplanes=num_channels[branch_index],
                                planes=num_inchannels[branch_index],
                                stride=stride,
                                downsample=upsample,
                                dilation=self.dilation[branch_index],
                                previous_dilation=self.dilation[branch_index],
                                norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=is_downsample))

            return nn.Sequential(*layers)

    def _make_branches(self, num_inchannels, num_branches, block, num_blocks, num_channels, norm_layer=nn.BatchNorm2d, relu_layer=nn.ReLU, use_bias=True, is_downsample=True):
        branches = []

        for i in range(num_branches):
            branches.append(self._make_one_branch(num_inchannels, i, block, num_blocks, num_channels, norm_layer=norm_layer, relu_layer=relu_layer, use_bias=use_bias, is_downsample=is_downsample))

        return nn.ModuleList(branches)

    def _make_fuse_layers(self, norm_layer=nn.BatchNorm2d, relu_layer=nn.ReLU, use_bias=True):
        if self.num_branches == 1:
            return None

        num_branches = self.num_branches
        num_inchannels = self.num_inchannels
        fuse_layers = []
        for i in range(num_branches):
            fuse_layer = []
            for j in range(num_branches):
                if j > i:
                    fuse_layer.append(nn.Sequential(nn.Conv2d(num_inchannels[j], num_inchannels[i], 1, 1, 0, bias=use_bias),
                                                    norm_layer(num_inchannels[i])))
                elif j == i:
                    fuse_layer.append(None)
                else:
                    conv3x3s = []
                    previous_dilated_branches = np.array(self.dilation[- (num_branches - j - 1):]) > 1
                    current_dilated_branches = True if self.dilation[i] > 1 else False
                    for branch_index in range(i - j):
                        if branch_index == i - j - 1:
                            num_outchannels_conv3x3 = num_inchannels[i]
                            if current_dilated_branches:
                                conv3x3s.append(nn.Sequential(nn.Conv2d(in_channels=num_inchannels[j],
                                                                        out_channels=num_outchannels_conv3x3,
                                                                        kernel_size=3,
                                                                        stride=1,
                                                                        padding=self.dilation[i],
                                                                        dilation=self.dilation[i],
                                                                        bias=use_bias),
                                                              norm_layer(num_outchannels_conv3x3)))
                            else:
                                conv3x3s.append(nn.Sequential(nn.Conv2d(in_channels=num_inchannels[j],
                                                                        out_channels=num_outchannels_conv3x3,
                                                                        kernel_size=3,
                                                                        stride=2,
                                                                        padding=1,
                                                                        bias=use_bias),
                                                              norm_layer(num_outchannels_conv3x3)))
                        else:
                            num_outchannels_conv3x3 = num_inchannels[j]
                            if previous_dilated_branches[branch_index]:
                                conv3x3s.append(nn.Sequential(nn.Conv2d(in_channels=num_inchannels[j],
                                                                        out_channels=num_outchannels_conv3x3,
                                                                        kernel_size=3,
                                                                        stride=1,
                                                                        padding=self.dilation[- (num_branches - j - 1):][branch_index], dilation=self.dilation[- (
                                                                            num_branches - j - 1):][branch_index],
                                                                        bias=use_bias),
                                                              norm_layer(num_outchannels_conv3x3),
                                                              relu_layer()))

                            else:
                                conv3x3s.append(nn.Sequential(nn.Conv2d(in_channels=num_inchannels[j],
                                                                        out_channels=num_outchannels_conv3x3,
                                                                        kernel_size=3,
                                                                        stride=2,
                                                                        padding=1,
                                                                        bias=use_bias),
                                                              norm_layer(num_outchannels_conv3x3),
                                                              relu_layer()))

                    fuse_layer.append(nn.Sequential(*conv3x3s))
            fuse_layers.append(nn.ModuleList(fuse_layer))

        return nn.ModuleList(fuse_layers)

    def get_num_inchannels(self):
        return self.num_inchannels

    def forward(self, x, h, w):
        if self.num_branches == 1:
            return [self.branches[0](x[0])]

        # edge_feats = []
        # j = 0
        # for i in range(self.num_branches):
        #     if i in self.edge_extract:
        #         temp = self.edges[j](x[i])
        #         edge_feats.append(F.interpolate(temp, size=(h, w), mode='bilinear', align_corners=True))
        #         j += 1
        #
        #     x[i] = self.branches[i](x[i])
        #
        # edge = self.final_edge(torch.cat(edge_feats, 1))

        x[3] = self.Layer3_Down1_Att(self.branches[3](x[3]))
        # x[3] = self.Layer3_Down1_Out(x[3])
        Layer2_Down1_Out = self.Layer2_Down1_Att(self.Layer2_Down1_Out(x[2]))
        x[2] = self.Layer2_Fusion2_Out(self.Layer2_Fusion1_Out(self.Layer2_Up_Out(self.Layer2_Up_HW(x[3])) + Layer2_Down1_Out) + Layer2_Down1_Out)
        Layer1_Down1_Out = self.Layer1_Down1_Att(self.Layer1_Down1_Out(x[1]))
        x[1] = self.Layer1_Fusion2_Out(self.Layer1_Fusion1_Out(self.Layer1_Up_Out(self.Layer1_Up_HW(x[2])) + Layer1_Down1_Out) + Layer1_Down1_Out)
        Layer0_Down1_Out = self.Layer0_Down1_Att(self.Layer0_Down1_Out(x[0]))
        x[0] = self.Layer0_Fusion2_Out(self.Layer0_Fusion1_Out(self.Layer0_Up_Out(self.Layer0_Up_HW(x[1])) + Layer0_Down1_Out) + Layer0_Down1_Out)

        # x_1024_8_8 = self.Layer3_Down1_2048_1024(x[3])
        # x_512_8_8 = self.Layer3_Down1_1024_512(x_1024_8_8)
        # x_256_8_8 = self.Layer3_Down1_512_256(x_512_8_8)
        # x_128_8_8 = self.Layer3_Down1_256_128(x_256_8_8)
        #
        # x_512_16_16 = self.Layer2_Down1_1024_512(x[2]+self.Layer2_Up_2048_1024(x[3]))
        # x_256_16_16 = self.Layer2_Down1_512_256(x_512_16_16+self.Layer2_Up_1024_512(x_1024_8_8))
        # x_128_16_16 = self.Layer2_Down1_256_128(x_256_16_16+self.Layer2_Up_512_256(x_512_8_8))
        # x_128_16_16 = self.Layer2_Fusion1_Out(x_128_16_16+self.Layer2_Up_256_128(x_256_8_8))
        #
        # x_256_32_32 = self.Layer1_Down1_512_256(x[1]+self.Layer1_Up_1024_512(x[2]))
        # x_128_32_32 = self.Layer1_Down1_256_128(x_256_32_32+self.Layer1_Up_512_256(x_512_16_16))
        # x_128_32_32 = self.Layer1_Fusion1_Out(x_128_32_32+self.Layer1_Up_256_128(x_256_16_16))
        #
        # x_128_64_64 = self.Layer1_Down0_256_128(x[0]+self.Layer0_Up_512_256(x[1]))
        # x_128_64_64 = self.Layer0_Fusion1_Out(x_128_64_64+self.Layer0_Up_256_128(x_256_32_32))
        #
        # x[3] = x_128_8_8
        # x[2] = x_128_16_16
        # x[1] = x_128_32_32
        # x[0] = x_128_64_64


        # x[1] = self.Layer1_Fusion4_Out(self.Layer1_Fusion3_Out(self.Layer1_Down2_Out(x[0]) + x[1]) + x[1])
        # x[2] = self.Layer2_Fusion4_Out(self.Layer2_Fusion3_Out(self.Layer2_Down2_Out(x[1]) + x[2]) + x[2])
        # x[3] = self.Layer3_Fusion4_Out(self.Layer3_Fusion3_Out(self.Layer3_Down2_Out(x[2]) + x[3]) + x[3])

        x_fuse = []
        for i in range(len(self.fuse_layers)):
            y = x[0] if i == 0 else self.fuse_layers[i][0](x[0])
            for j in range(1, self.num_branches):
                if i == j:
                    y = y + x[j]
                elif j > i:
                    width_output = x[i].shape[-1]
                    height_output = x[i].shape[-2]
                    y = y + F.interpolate(self.fuse_layers[i][j](x[j]), size=[height_output, width_output], mode='bilinear', align_corners=True)
                else:
                    y = y + self.fuse_layers[i][j](x[j])

            x_fuse.append(self.branches_up[i](y))
            # x_fuse.append(F.interpolate(self.relu(y), size=(h, w), mode='bilinear', align_corners=True))

        out3 = self.resblock3(self.upsample4_3(x_fuse[3]) + x_fuse[2])
        # out2 = self.resblock2(self.upsample3_2(out3) + self.upsample4_2(x_fuse[3]) + x_fuse[1])
        # out1 = self.resblock1(self.upsample2(out2) + self.upsample3_1(out3) + self.upsample4_1(x_fuse[3]) + x_fuse[0])
        out2 = self.resblock2(self.upsample3_2(out3) + x_fuse[1])
        out1 = self.resblock1(self.upsample2(out2) + x_fuse[0])
        out  = self.upsample1(out1)
        out  = self.upsample0(out)
        out = self.upsample(out)
        return x_fuse, out
        # return x_fuse, edge, out
