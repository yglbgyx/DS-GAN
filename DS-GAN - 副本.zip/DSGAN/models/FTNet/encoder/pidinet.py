"""
Author: Zhuo Su, Wenzhe Liu
Date: Feb 18, 2021
"""

import math
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

from .ops import Conv2d
from .config import config_model, config_model_converted, config_model_carv

class CSAM(nn.Module):
    """
    Compact Spatial Attention Module
    """
    def __init__(self, channels):
        super(CSAM, self).__init__()

        mid_channels = 4
        self.relu1 = nn.ReLU()
        self.conv1 = nn.Conv2d(channels, mid_channels, kernel_size=1, padding=0)
        self.conv2 = nn.Conv2d(mid_channels, 1, kernel_size=3, padding=1, bias=False)
        self.sigmoid = nn.Sigmoid()
        nn.init.constant_(self.conv1.bias, 0)

    def forward(self, x):
        y = self.relu1(x)
        y = self.conv1(y)
        y = self.conv2(y)
        y = self.sigmoid(y)

        return x * y

class CDCM(nn.Module):
    """
    Compact Dilation Convolution based Module
    """
    def __init__(self, in_channels, out_channels):
        super(CDCM, self).__init__()

        self.relu1 = nn.ReLU()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=1, padding=0)
        self.conv2_1 = nn.Conv2d(out_channels, out_channels, kernel_size=3, dilation=5, padding=5, bias=False)
        self.conv2_2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, dilation=7, padding=7, bias=False)
        self.conv2_3 = nn.Conv2d(out_channels, out_channels, kernel_size=3, dilation=9, padding=9, bias=False)
        self.conv2_4 = nn.Conv2d(out_channels, out_channels, kernel_size=3, dilation=11, padding=11, bias=False)
        nn.init.constant_(self.conv1.bias, 0)
        
    def forward(self, x):
        x = self.relu1(x)
        x = self.conv1(x)
        x1 = self.conv2_1(x)
        x2 = self.conv2_2(x)
        x3 = self.conv2_3(x)
        x4 = self.conv2_4(x)
        return x1 + x2 + x3 + x4


class MapReduce(nn.Module):
    """
    Reduce feature maps into a single edge map
    """
    def __init__(self, channels):
        super(MapReduce, self).__init__()
        self.conv = nn.Conv2d(channels, 1, kernel_size=1, padding=0)
        nn.init.constant_(self.conv.bias, 0)

    def forward(self, x):
        return self.conv(x)


class PDCBlock(nn.Module):
    def __init__(self, pdc, inplane, ouplane, stride=1):
        super(PDCBlock, self).__init__()
        self.stride=stride

        if self.stride > 1:
            self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
            self.shortcut = nn.Conv2d(inplane, ouplane, kernel_size=1, padding=0)
        self.conv1 = Conv2d(pdc, inplane, inplane, kernel_size=3, padding=1, groups=inplane, bias=False)
        self.relu2 = nn.ReLU()
        self.conv2 = nn.Conv2d(inplane, ouplane, kernel_size=1, padding=0, bias=False)

    def forward(self, x):
        if self.stride > 1:
            x = self.pool(x)
        y = self.conv1(x)
        y = self.relu2(y)
        y = self.conv2(y)
        if self.stride > 1:
            x = self.shortcut(x)
        y = y + x
        return y

class Layer_PDC(nn.Module):
    def __init__(self, inplane, ouplane, model='carv', stride=1):
        super(Layer_PDC, self).__init__()
        pdcs = config_model_carv(model)
        self.block1 = PDCBlock(pdcs[0], inplane, ouplane, stride=stride)
        self.block2 = PDCBlock(pdcs[1], ouplane, ouplane)
        self.block3 = PDCBlock(pdcs[2], ouplane, ouplane)
        self.block4 = PDCBlock(pdcs[3], ouplane, ouplane)

    def forward(self, x):
        x = self.block1(x)
        x = self.block2(x)
        x = self.block3(x)
        x = self.block4(x)

        return x

class PDCBlock_converted(nn.Module):
    """
    CPDC, APDC can be converted to vanilla 3x3 convolution
    RPDC can be converted to vanilla 5x5 convolution
    """
    def __init__(self, pdc, inplane, ouplane, stride=1):
        super(PDCBlock_converted, self).__init__()
        self.stride=stride

        if self.stride > 1:
            self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
            self.shortcut = nn.Conv2d(inplane, ouplane, kernel_size=1, padding=0)
        if pdc == 'rd':
            self.conv1 = nn.Conv2d(inplane, inplane, kernel_size=5, padding=2, groups=inplane, bias=False)
        else:
            self.conv1 = nn.Conv2d(inplane, inplane, kernel_size=3, padding=1, groups=inplane, bias=False)
        self.relu2 = nn.ReLU()
        self.conv2 = nn.Conv2d(inplane, ouplane, kernel_size=1, padding=0, bias=False)

    def forward(self, x):
        if self.stride > 1:
            x = self.pool(x)
        y = self.conv1(x)
        y = self.relu2(y)
        y = self.conv2(y)
        if self.stride > 1:
            x = self.shortcut(x)
        y = y + x
        return y

class PiDiNet(nn.Module):
    def __init__(self, inplane, pdcs, dil=None, sa=False, convert=False, use_bias=True, norm_layer=nn.InstanceNorm2d, relu_layer=nn.ReLU):
        super(PiDiNet, self).__init__()

        self.feature_list = []

        self.inplane = inplane
        # self.conv1 = nn.Sequential(nn.ReflectionPad2d(3),
        #                            nn.Conv2d(3, self.inplane, 7, 2, 0, bias=use_bias),
        #                            norm_layer(self.inplane),
        #                            relu_layer())
        # self.conv1 = Conv2d(pdcs[0], 3, self.inplane, kernel_size=3, padding=1, stride=2)
        # if convert:
        #     if pdcs[0] == 'rd':
        #         init_kernel_size = 5
        #         init_padding = 2
        #     else:
        #         init_kernel_size = 3
        #         init_padding = 1
        #     self.init_block = nn.Conv2d(3, self.inplane, kernel_size=init_kernel_size, padding=init_padding, bias=False)
        #     block_class = PDCBlock_converted
        # else:
        #     # self.init_block = Conv2d(pdcs[0], self.inplane, self.inplane, kernel_size=3, padding=1)
        #     block_class = PDCBlock

        block_class = PDCBlock
        # self.layer0 = Layer_PDC(3, self.inplane, stride=2)
        self.block0_1 = block_class(pdcs[16], 3, self.inplane, stride=2)
        self.block0_2 = block_class(pdcs[17], self.inplane, self.inplane)
        self.block0_3 = block_class(pdcs[18], self.inplane, self.inplane)
        self.block0_4 = block_class(pdcs[19], self.inplane, self.inplane)
        self.feature_list.append(self.inplane)

        inplane = self.inplane
        self.inplane = self.inplane * 4
        # self.layer1 = Layer_PDC(inplane, self.inplane, stride=2)
        self.block1_1 = block_class(pdcs[0], inplane, self.inplane, stride=2)
        self.block1_2 = block_class(pdcs[1], self.inplane, self.inplane)
        self.block1_3 = block_class(pdcs[2], self.inplane, self.inplane)
        self.block1_4 = block_class(pdcs[3], self.inplane, self.inplane)
        self.feature_list.append(self.inplane) # C

        inplane = self.inplane
        self.inplane = self.inplane * 2
        # self.layer2 = Layer_PDC(inplane, self.inplane, stride=2)
        self.block2_1 = block_class(pdcs[4], inplane, self.inplane, stride=2)
        self.block2_2 = block_class(pdcs[5], self.inplane, self.inplane)
        self.block2_3 = block_class(pdcs[6], self.inplane, self.inplane)
        self.block2_4 = block_class(pdcs[7], self.inplane, self.inplane)
        self.feature_list.append(self.inplane) # 2C
        
        inplane = self.inplane
        self.inplane = self.inplane * 2
        # self.layer3 = Layer_PDC(inplane, self.inplane, stride=2)
        self.block3_1 = block_class(pdcs[8], inplane, self.inplane, stride=2)
        self.block3_2 = block_class(pdcs[9], self.inplane, self.inplane)
        self.block3_3 = block_class(pdcs[10], self.inplane, self.inplane)
        self.block3_4 = block_class(pdcs[11], self.inplane, self.inplane)
        self.feature_list.append(self.inplane) # 4C

        inplane = self.inplane
        self.inplane = self.inplane * 2
        # self.layer4 = Layer_PDC(inplane, self.inplane, stride=2)
        self.block4_1 = block_class(pdcs[12], inplane, self.inplane, stride=2)
        self.block4_2 = block_class(pdcs[13], self.inplane, self.inplane)
        self.block4_3 = block_class(pdcs[14], self.inplane, self.inplane)
        self.block4_4 = block_class(pdcs[15], self.inplane, self.inplane)
        self.feature_list.append(self.inplane) # 4C

        # self.conv_reduces = nn.ModuleList()
        # if self.sa and self.dil is not None:
        #     self.attentions = nn.ModuleList()
        #     self.dilations = nn.ModuleList()
        #     for i in range(4):
        #         self.dilations.append(CDCM(self.fuseplanes[i], self.dil))
        #         self.attentions.append(CSAM(self.dil))
        #         self.conv_reduces.append(MapReduce(self.dil))
        # elif self.sa:
        #     self.attentions = nn.ModuleList()
        #     for i in range(4):
        #         self.attentions.append(CSAM(self.fuseplanes[i]))
        #         self.conv_reduces.append(MapReduce(self.fuseplanes[i]))
        # elif self.dil is not None:
        #     self.dilations = nn.ModuleList()
        #     for i in range(4):
        #         self.dilations.append(CDCM(self.fuseplanes[i], self.dil))
        #         self.conv_reduces.append(MapReduce(self.dil))
        # else:
        #     for i in range(4):
        #         self.conv_reduces.append(MapReduce(self.fuseplanes[i]))
        #
        # self.classifier = nn.Conv2d(4, 1, kernel_size=1) # has bias
        # nn.init.constant_(self.classifier.weight, 0.25)
        # nn.init.constant_(self.classifier.bias, 0)
        #
        # print('initialization done')

    def get_weights(self):
        conv_weights = []
        bn_weights = []
        relu_weights = []
        for pname, p in self.named_parameters():
            if 'bn' in pname:
                bn_weights.append(p)
            elif 'relu' in pname:
                relu_weights.append(p)
            else:
                conv_weights.append(p)

        return conv_weights, bn_weights, relu_weights

    def forward(self, x):
        H, W = x.size()[2:]

        # x = self.init_block(x)
        x1 = self.conv1(x)

        x1 = self.block1_1(x1)
        x1 = self.block1_2(x1)
        x1 = self.block1_3(x1)
        x1 = self.block1_4(x1)

        x2 = self.block2_1(x1)
        x2 = self.block2_2(x2)
        x2 = self.block2_3(x2)
        x2 = self.block2_4(x2)

        x3 = self.block3_1(x2)
        x3 = self.block3_2(x3)
        x3 = self.block3_3(x3)
        x3 = self.block3_4(x3)

        x4 = self.block4_1(x3)
        x4 = self.block4_2(x4)
        x4 = self.block4_3(x4)
        x4 = self.block4_4(x4)

        # x_fuses = []
        # if self.sa and self.dil is not None:
        #     for i, xi in enumerate([x1, x2, x3, x4]):
        #         x_fuses.append(self.attentions[i](self.dilations[i](xi)))
        # elif self.sa:
        #     for i, xi in enumerate([x1, x2, x3, x4]):
        #         x_fuses.append(self.attentions[i](xi))
        # elif self.dil is not None:
        #     for i, xi in enumerate([x1, x2, x3, x4]):
        #         x_fuses.append(self.dilations[i](xi))
        # else:
        #     x_fuses = [x1, x2, x3, x4]
        #
        # e1 = self.conv_reduces[0](x_fuses[0])
        # e1 = F.interpolate(e1, (H, W), mode="bilinear", align_corners=False)
        #
        # e2 = self.conv_reduces[1](x_fuses[1])
        # e2 = F.interpolate(e2, (H, W), mode="bilinear", align_corners=False)
        #
        # e3 = self.conv_reduces[2](x_fuses[2])
        # e3 = F.interpolate(e3, (H, W), mode="bilinear", align_corners=False)
        #
        # e4 = self.conv_reduces[3](x_fuses[3])
        # e4 = F.interpolate(e4, (H, W), mode="bilinear", align_corners=False)
        #
        # outputs = [e1, e2, e3, e4]
        #
        # output = self.classifier(torch.cat(outputs, dim=1))
        # #if not self.training:
        # #    return torch.sigmoid(output)
        #
        # outputs.append(output)
        # outputs = [torch.sigmoid(r) for r in outputs]
        # return outputs


def pidinet_tiny(args):
    pdcs = config_model(args.config)
    dil = 8 if args.dil else None
    return PiDiNet(20, pdcs, dil=dil, sa=args.sa)

def pidinet_small(args):
    pdcs = config_model(args.config)
    dil = 12 if args.dil else None
    return PiDiNet(30, pdcs, dil=dil, sa=args.sa)

def pidinet():
    pdcs = config_model('carv4')
    # dil = 24 if args.dil else None
    return PiDiNet(64, pdcs)



## convert pidinet to vanilla cnn

def pidinet_tiny_converted(args):
    pdcs = config_model_converted(args.config)
    dil = 8 if args.dil else None
    return PiDiNet(20, pdcs, dil=dil, sa=args.sa, convert=True)

def pidinet_small_converted(args):
    pdcs = config_model_converted(args.config)
    dil = 12 if args.dil else None
    return PiDiNet(30, pdcs, dil=dil, sa=args.sa, convert=True)

def pidinet_converted(args):
    pdcs = config_model_converted(args.config)
    dil = 24 if args.dil else None
    return PiDiNet(60, pdcs, dil=dil, sa=args.sa, convert=True)

import argparse
if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='PyTorch Diff Convolutional Networks (Train)')

    parser.add_argument('--model', type=str, default='pidinet',
                        help='model to train the dataset')
    parser.add_argument('--sa', action='store_true',
                        help='use attention in diffnet')
    parser.add_argument('--dil', action='store_true',
                        help='use dilation in diffnet')
    parser.add_argument('--config', type=str, default='nas-all',
                        help='model configurations, please refer to models/config.py for possible configurations')
    parser.add_argument('--seed', type=int, default=None,
                        help='random seed (default: None)')
    parser.add_argument('--gpu', type=str, default='',
                        help='gpus available')

    parser.add_argument('--epochs', type=int, default=150,
                        help='number of total epochs to run')
    parser.add_argument('-j', '--workers', type=int, default=4,
                        help='number of data loading workers')
    parser.add_argument('--eta', type=float, default=0.3,
                        help='threshold to determine the ground truth')

    args = parser.parse_args()

    device = torch.device('cuda')
    test_model = pidinet(args)
    test_model.to(device)
    input = torch.randn(1, 3, 256, 256, dtype=torch.float).to(device)
    output = test_model(input)
    print(test_model)
    print(input.shape)
    print(output.shape)